#include <opencv2/opencv.hpp>
#include <opencv2/gpu/gpu.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>

//Maybe in OpenCV2.2 the correct include statement would be:
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

int main(int, char**)
{
	VideoCapture capLeft(1); // open the Left camera
	VideoCapture capRight(0); // open the Right camera

	int numSnapshotLeft = 0, numSnapshotRight = 0; //Contador de fotos...
	string snapshotFilenameLeft = "0", snapshotFilenameRight = "0"; //Nombre del archivo de la captura...

	char key = 0;

	if(!capLeft.isOpened() || !capRight.isOpened())  // check if we succeeded
	{
		cerr << "ERROR: No se pudieron abrir la/s camaras." << endl;
		return -1;
	}

	namedWindow("CAMARA IZQUIERDA",1);
	namedWindow("CAMARA DERECHA",1);

	cout << "Puedes presionar la letra 'C' para realizar una captura de las camaras." << endl;

	while(key != 27)
	{
		bool isValid = true;

		Mat frameLeft;
		Mat frameRight;
		Mat imagenIzq;
		Mat imagenDer;

		try
		{
			capLeft >> frameLeft; // get a new frame from left camera
			capRight >> frameRight; //get a new frame from right camera
		}
		catch( Exception& e )
		{
			cout << "Se ha producido un error. Se ignora el marco. " << e.err << endl;
			isValid = false;
		}

		if (isValid)
		{
			try
			{
				imshow("CAMARA IZQUIERDA", frameLeft);
				imshow("CAMARA DERECHA", frameRight);

				/************************************************************
				 *    This is the place for all the cool stuff that you      *
				 *    want to do with your stereo images                     *
				 ************************************************************/

				//TODO:...

				if(key == 99)
				{
					cout << "Captura imagen izquierda" << endl;
					imwrite("imgLeft_" + snapshotFilenameLeft + ".png", frameLeft);
					numSnapshotLeft++;
					snapshotFilenameLeft = static_cast<ostringstream*>(&(ostringstream() << numSnapshotLeft))->str();
					cout << "Captura imagen derecha" << endl;
					imwrite("imgRight_" + snapshotFilenameRight + ".png", frameRight);
					numSnapshotRight++;
					snapshotFilenameRight = static_cast<ostringstream*>(&(ostringstream() << numSnapshotRight))->str();
				}

				if(key == 97)
				{
					Mat imgI = imread("imgLeft_0.png");
					Mat imgD = imread("imgRight_0.png");
					Mat Anaglifo;

					for(int i=0; i<imgI.rows; i++)
					{
						for(int j=0; j<imgI.cols; j++)
						{
							// You can now access the pixel value with cv::Vec3b 0->Azul; 1->Verde; 2->Rojo
							imgI.at<Vec3b>(i,j)[0] = 0;
							imgI.at<Vec3b>(i,j)[1] = 0;
						}
					}

					for(int i=0; i<imgD.rows; i++)
					{
						for(int j=0; j<imgD.cols; j++)
						{
							// You can now access the pixel value with cv::Vec3b
							imgD.at<Vec3b>(i,j)[2] = 0;
						}
					}

					namedWindow( "IMAGEN MODIFICADA IZQ",1);
					imshow( "IMAGEN MODIFICADA IZQ", imgI );

					namedWindow( "IMAGEN MODIFICADA DER",1);
					imshow( "IMAGEN MODIFICADA DER", imgD );

					double alpha = 0.5;
					double beta = 0.5;

					addWeighted( imgI, alpha, imgD, beta, 0.0, Anaglifo);

					namedWindow( "ANAGLIFO",1);
					imshow( "ANAGLIFO", Anaglifo );
				}

				if(key == 109)
				{
					int spatialRad = 10;			// mean shift parameters
					int colorRad = 10;
					int maxPyrLevel = 2;

					Mat imgLeftNormal = imread("imgLeft_0.png");
					Mat ImgLeftFilter;
					Mat imgRightNormal = imread("imgRight_0.png");
					Mat ImgRightFilter;

					pyrMeanShiftFiltering(imgLeftNormal, ImgLeftFilter, spatialRad, colorRad, maxPyrLevel );
					pyrMeanShiftFiltering(imgRightNormal, ImgRightFilter, spatialRad, colorRad, maxPyrLevel );

					namedWindow( "Mean Shift Filtro Izquierda",1);
					imshow( "Mean Shift Filtro Izquierda", ImgLeftFilter );
					namedWindow( "Mean Shift Filtro Derecha",1);
					imshow( "Mean Shift Filtro Derecha", ImgRightFilter );

				}


			}
			catch( Exception& e )
			{
				/************************************************************
				 *    Sometimes an "Unrecognized or unsuported array type"   *
				 *    exception is received so we handle it to avoid dying   *
				 ************************************************************/
				cout << "An exception occurred. Ignoring frame. " << e.err << endl;
			}
		}
		key = waitKey(20);

//		imagenIzq = imread("imgLeft_0.png");
//		imagenDer = imread("imgRight_0.png");
//
//		Mat dst;
//
//		GaussianBlur(imagenIzq, dst, Size(13,7), 8);
//		//medianBlur(imagenIzq, dst, 5);
//
//		namedWindow( "IMAGEN IZQUIERDA",1);
//		imshow( "IMAGEN IZQUIERDA", imagenIzq );
//
//		namedWindow( "IMAGEN DERECHA",1);
//		imshow( "IMAGEN DERECHA", imagenDer );
//
//		namedWindow( "IMAGEN MODIFICADA",1);
//		imshow( "IMAGEN MODIFICADA", dst );

	}
	// the camera will be deinitialized automatically in VideoCapture destructor



	//waitKey(10000);

	return 0;
}
